﻿namespace ukol.Components.Data
{
        public class Polozka
        {
            public int Id { get; set; }
            public string Nazev { get; set; }
            public string Jednotka { get; set; }
        }
    

}
